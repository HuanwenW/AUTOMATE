
import networkx as nx
import numpy as np



def build_graph(train_data):
    graph = nx.DiGraph()
    for seq in train_data:
        for i in range(len(seq) - 1):
            if graph.get_edge_data(seq[i], seq[i + 1]) is None:
                weight = 1
            else:
                weight = graph.get_edge_data(seq[i], seq[i + 1])['weight'] + 1
            graph.add_edge(seq[i], seq[i + 1], weight=weight)
    for node in graph.nodes:
        sum = 0
        for j, i in graph.in_edges(node):
            sum += graph.get_edge_data(j, i)['weight']
        if sum != 0:
            for j, i in graph.in_edges(i):
                graph.add_edge(j, i, weight=graph.get_edge_data(j, i)['weight'] / sum)
    return graph

def data_masks(all_usr_pois, item_tail):
    # print(all_usr_pois)
    # print(item_tail)
    us_lens = [len(upois) for upois in all_usr_pois]
    len_max = max(us_lens)

    us_pois = [upois + item_tail * (len_max - le) for upois, le in zip(all_usr_pois, us_lens)]
    # 构造固定长度的列表，这一步设定是否是用户点击的商品，是，则对应列表的位置设为１，否则设为0
    us_msks = [[1] * le + [0] * (len_max - le) for le in us_lens]
    return us_pois, us_msks, len_max


def split_validation(train_set, valid_portion):
    train_set_x, train_set_y = train_set
    n_samples = len(train_set_x)
    sidx = np.arange(n_samples, dtype='int32')
    np.random.shuffle(sidx)
    n_train = int(np.round(n_samples * (1. - valid_portion)))
    valid_set_x = [train_set_x[s] for s in sidx[n_train:]]# list形式
    valid_set_y = [train_set_y[s] for s in sidx[n_train:]]
    train_set_x = [train_set_x[s] for s in sidx[:n_train]]
    train_set_y = [train_set_y[s] for s in sidx[:n_train]]

    return (train_set_x, train_set_y), (valid_set_x, valid_set_y)

# 这里的data是将用户点击序列，序列[0:-1]作为用户行为，序列[-1]作为预测的标签，即训练目标
class Data1():
    def __init__(self, data, shuffle=False, graph=None):
        # print("..................")
        # # print(data)
        # data.to_csv('data.tsv', sep='\t', index=False)
        # data数据格式：训练集：([[1, 2], [1], [4]...], [5,2,5...])
        inputs = data[0] # 取文件中第一列
        inputs, mask, len_max = data_masks(inputs, [0]) #　调用本文件的data_masks()函数
        self.inputs = np.asarray(inputs)
        self.mask = np.asarray(mask)
        self.len_max = len_max
        self.targets = np.asarray(data[1])# 标签
        self.length = len(inputs)
        self.shuffle = shuffle
        self.graph = graph

    #生成batch函数
    def generate_batch(self, batch_size):# batch_size=100
        if self.shuffle:
            shuffled_arg = np.arange(self.length)
            np.random.shuffle(shuffled_arg)
            self.inputs = self.inputs[shuffled_arg]
            self.mask = self.mask[shuffled_arg]
            self.targets = self.targets[shuffled_arg]
        n_batch = int(self.length / batch_size)
        if self.length % batch_size != 0:
            n_batch += 1

        slices = np.split(np.arange(n_batch * batch_size), n_batch)
        slices[-1] = slices[-1][:(self.length - batch_size * (n_batch - 1))] # [-1]表示数组最后一个元素
        return slices

    def get_slice(self, i):
        inputs, mask, targets = self.inputs[i], self.mask[i], self.targets[i]
        items, n_node, A, alias_inputs = [], [], [], []

        for u_input in inputs:
            n_node.append(len(np.unique(u_input)))
        max_n_node = np.max(n_node)
        A_edge = []
        B = []
        for u_input in inputs:

            node = np.unique(u_input)#去重--第一次循环结果[0,85]
            items.append(node.tolist() + (max_n_node - len(node)) * [0])# 后面追加0的个数为((max_n_node - len(node))个
            u_A = np.zeros((max_n_node, max_n_node))# 生成max_n_node　*　max_n_node的矩阵

            edge = []
            # print('u_input',u_input)
            for i in np.arange(len(u_input) - 1):#遍历各个元素
                if u_input[i + 1] == 0:
                    break
                # print(node, u_input, u_input[i])
                u = np.where(node == u_input[i])[0][0]
                v = np.where(node == u_input[i + 1])[0][0]
                # print('---', u, v)
                u_A[u][v] = 1
                edge.append([u,v])

            A.append(u_A)
            A_edge.append(edge)
            alias_inputs.append([np.where(node == i)[0][0] for i in u_input])
        return alias_inputs, A, items, mask, targets, A_edge

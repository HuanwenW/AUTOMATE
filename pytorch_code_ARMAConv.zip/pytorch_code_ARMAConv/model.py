#!/usr/bin/env python36
# -*- coding: utf-8 -*-

import math
import torch
import datetime
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import Module, Parameter

from torch_geometric.data import Data, DataLoader

from torch.nn import Parameter
import torch.nn.functional as F
from torch_scatter import scatter_add

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class ARMAConv(torch.nn.Module):
    r"""The ARMA graph convolutional operator from the `"Graph Neural Networks
    with Convolutional ARMA Filters" <https://arxiv.org/abs/1901.01343>`_ paper

    .. math::
        \mathbf{X}^{\prime} = \frac{1}{K} \sum_{k=1}^K \mathbf{X}_k^{(T)},

    with :math:`\mathbf{X}_k^{(T)}` being recursively defined by

    .. math::
        \mathbf{X}_k^{(t+1)} = \sigma \left( \mathbf{\hat{L}}
        \mathbf{X}_k^{(t)} \mathbf{W} + \mathbf{X}^{(0)} \mathbf{V} \right),

    where :math:`\mathbf{\hat{L}} = \mathbf{I} - \mathbf{L} = \mathbf{D}^{-1/2}
    \mathbf{A} \mathbf{D}^{-1/2}` denotes the
    modified Laplacian :math:`\mathbf{L} = \mathbf{I} - \mathbf{D}^{-1/2}
    \mathbf{A} \mathbf{D}^{-1/2}`.

    Args:
        in_channels (int): Size of each input sample :math:`\mathbf{x}^{(t)}`.
        out_channels (int): Size of each output sample
            :math:`\mathbf{x}^{(t+1)}`.
        num_stacks (int, optional): Number of parallel stacks :math:`K`.
            (default: :obj:`1`).
        num_layers (int, optional): Number of layers :math:`T`.
            (default: :obj:`1`)
        act (callable, optional): Activation function :math:`\sigma`.
            (default: :meth:`torch.nn.functional.ReLU`)
        shared_weights (int, optional): If set to :obj:`True` the layers in
            each stack will share the same parameters. (default: :obj:`False`)
        dropout (float, optional): Dropout probability of the skip connection.
            (default: :obj:`0`)
        bias (bool, optional): If set to :obj:`False`, the layer will not learn
            an additive bias. (default: :obj:`True`)
    """

    def __init__(self,
                 in_channels,
                 out_channels,
                 num_stacks=4,
                 num_layers=2,
                 shared_weights=False,
                 act=F.relu,
                 dropout=0,
                 bias=True):
        super(ARMAConv, self).__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_stacks = num_stacks
        self.num_layers = num_layers
        self.act = act
        self.shared_weights = shared_weights
        self.dropout = dropout

        K, T, F_in, F_out = num_stacks, num_layers, in_channels, out_channels

        w = torch.nn.Parameter(torch.Tensor(K, F_in, F_out))
        self.ws = torch.nn.ParameterList([w])
        for i in range(min(1, T - 1) if shared_weights else T - 1):
            self.ws.append(Parameter(torch.Tensor(K, F_out, F_out)))

        self.vs = torch.nn.ParameterList([])
        for i in range(1 if shared_weights else T):
            self.vs.append(Parameter(torch.Tensor(K, F_in, F_out)))

        if bias:
            self.bias = torch.nn.ParameterList([])
            for i in range(1 if shared_weights else T):
                self.bias.append(Parameter(torch.Tensor(K, 1, F_out)))
        else:
            self.register_parameter('bias', None)

        self.reset_parameters()

    def reset_parameters(self):
        for w in self.ws:
            glorot(w)
        for v in self.vs:
            glorot(v)
        if self.bias is not None:
            for bias in self.bias:
                zeros(bias)

    def forward(self, x, edge_index, edge_weight=None):
        """"""
        if edge_weight is None:
            edge_weight = x.new_ones((edge_index.size(1),))
        edge_weight = edge_weight.view(-1)
        assert edge_weight.size(0) == edge_index.size(1)

        row, col = edge_index
        deg = scatter_add(edge_weight, row, dim=0, dim_size=x.size(0))
        deg_inv = deg.pow(-0.5)
        deg_inv[deg_inv == float('inf')] = 0

        lap = deg_inv[row] * edge_weight * deg_inv[col]

        x = x.unsqueeze(0)
        out = x
        for t in range(self.num_layers):
            w = self.ws[min(t, 1) if self.shared_weights else t]
            out = torch.matmul(out, w)
            out = out[:, col] * lap.view(1, -1, 1)
            out = scatter_add(out, row, dim=1, dim_size=x.size(1))

            skip = F.dropout(x, p=self.dropout, training=self.training)
            v = self.vs[0 if self.shared_weights else t]
            skip = torch.matmul(skip, v)

            out = out + skip

            if self.bias is not None:
                bias = self.bias[0 if self.shared_weights else t]
                out = out + bias

            if self.act:
                out = self.act(out)

        return out.mean(dim=0)

    def __repr__(self):
        return '{}({}, {}, num_stacks={}, num_layers={})'.format(
            self.__class__.__name__, self.in_channels, self.out_channels,
            self.num_stacks, self.num_layers)

class GCN(torch.nn.Module):
    """
    Graph embedding, which based on GCN and mix pooling
    """
    def __init__(self, node_dim, n_dim):
        super(GCN, self).__init__()
        self.fea_size = node_dim
        self.n_dim = n_dim
       # self.conv1 = ARMAConv(node_dim, 100)
        self.conv1 = ARMAConv(node_dim, n_dim)
        self.conv2 = ARMAConv(n_dim, 100)

    def forward(self, data, bool=True):
        x, edge_index = data.x, data.edge_index
        x = F.relu(self.conv1(x, edge_index))  # emb_init[num, dim]
        x = F.dropout(x, training=self.training)
        x = F.relu(self.conv2(x, edge_index))
        return x

class SessionGraph(Module):
    def __init__(self, opt, n_node):
        super(SessionGraph, self).__init__()
        self.hidden_size = opt.hiddenSize # 100
        self.n_node = n_node #
        self.batch_size = opt.batchSize # 100
        self.nonhybrid = opt.nonhybrid
        self.embedding = nn.Embedding(self.n_node, self.hidden_size)
        # self.gnn = GNN(self.hidden_size, step=opt.step)
        self.gcn = GCN(node_dim = self.hidden_size, n_dim = 256)
        self.linear_one = nn.Linear(self.hidden_size, self.hidden_size, bias=True)
        self.linear_two = nn.Linear(self.hidden_size, self.hidden_size, bias=True)
        self.linear_three = nn.Linear(self.hidden_size, 1, bias=False)
        self.linear_transform = nn.Linear(self.hidden_size * 2, self.hidden_size, bias=True)
        self.loss_function = nn.CrossEntropyLoss()
        self.optimizer = torch.optim.Adam(self.parameters(), lr=opt.lr, weight_decay=opt.l2)
        self.scheduler = torch.optim.lr_scheduler.StepLR(self.optimizer, step_size=opt.lr_dc_step, gamma=opt.lr_dc)
        self.reset_parameters()
#
    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            weight.data.uniform_(-stdv, stdv)

    def compute_scores(self, hidden, mask):

        ht = hidden[torch.arange(mask.shape[0]).long(), torch.sum(mask, 1) - 1]  # batch_size x latent_size
        q1 = self.linear_one(ht).view(ht.shape[0], 1, ht.shape[1])  # batch_size x 1 x latent_size
        q2 = self.linear_two(hidden)  # batch_size x seq_length x latent_size
        alpha = self.linear_three(torch.sigmoid(q1 + q2))
        a = torch.sum(alpha * hidden * mask.view(mask.shape[0], -1, 1).float(), 1) # 参数依次为： 输入张量，缩减维度，结果张量
        # print(alpha.shape, a.shape)
        if not self.nonhybrid:
            a = self.linear_transform(torch.cat([a, ht], 1)) # 加上局部的偏好
        b = self.embedding.weight[1:]  # n_nodes x latent_size
        scores = torch.matmul(a, b.transpose(1, 0))
        # print(scores.shape)#shape:[100, 309]
        return scores

    def forward(self, inputs, A_edge):
        hidden = self.embedding(inputs)

        graph_data = Deal_data(hidden, A_edge)
        hidden = self.gcn(graph_data)
        hidden = hidden.view(len(inputs),len(hidden)//len(inputs),-1)

        return hidden


def trans_to_cuda(variable):
    if torch.cuda.is_available():
        return variable.cuda()
    else:
        return variable


def trans_to_cpu(variable):
    if torch.cuda.is_available():
        return variable.cpu()
    else:
        return variable


def Deal_data(items, A_edge):
    data_list = []
    for i in range(len(items)):
        edge_index = torch.tensor(A_edge[i], dtype=torch.long)
        x = torch.tensor(items[i], dtype = torch.float)
        data = Data(x = x, edge_index = edge_index.t().contiguous())
        data_list.append(data)
    loader = DataLoader(data_list, batch_size=100, shuffle=False)
    for i, batch in enumerate(loader):
       # print(i) # 0
        data1 = batch.to(device)
    return data1

def forward(model, i, data):

    alias_inputs, A, items, mask, targets, A_edge = data.get_slice(i)


    alias_inputs = trans_to_cuda(torch.Tensor(alias_inputs).long())# alias_inputs: [100, 16]
    items = trans_to_cuda(torch.Tensor(items).long())

    mask = trans_to_cuda(torch.Tensor(mask).long())# [100, 16]
    hidden = model(items, A_edge)
    get = lambda i: hidden[i][alias_inputs[i]]
    seq_hidden = torch.stack([get(i) for i in torch.arange(len(alias_inputs)).long()])

    return targets, model.compute_scores(seq_hidden, mask)


def train_test(model, train_data, test_data):
    model.scheduler.step()

    print('start training: ', datetime.datetime.now())# 输出当前时间
    model.train()
    total_loss = 0.0

    slices = train_data.generate_batch(model.batch_size)
    for i, j in zip(slices, np.arange(len(slices))):
        model.optimizer.zero_grad()

        targets, scores = forward(model, i, train_data)
        targets = trans_to_cuda(torch.Tensor(targets).long())
        loss = model.loss_function(scores, targets - 1)
        loss.backward()
        model.optimizer.step()
        total_loss += loss
        if j % int(len(slices) / 5 + 1) == 0:
            print('[%d/%d] Loss: %.4f' % (j, len(slices), loss.item()))
    print('\tLoss:\t%.3f' % total_loss)

    print('start predicting: ', datetime.datetime.now())
    model.eval()
    hit, mrr = [], []
    slices = test_data.generate_batch(model.batch_size)
    for i in slices:
        targets, scores = forward(model, i, test_data)
        sub_scores = scores.topk(20)[1]
        sub_scores = trans_to_cpu(sub_scores).detach().numpy()
        for score, target, mask in zip(sub_scores, targets, test_data.mask):
            hit.append(np.isin(target - 1, score))
            if len(np.where(score == target - 1)[0]) == 0:
                mrr.append(0)
            else:
                mrr.append(1 / (np.where(score == target - 1)[0][0] + 1))
    hit = np.mean(hit) * 100
    mrr = np.mean(mrr) * 100
    return hit, mrr
